The files prefixed with (CC BY SA) are redistributed under the Creative Commons Attribution-ShareAlike 4.0 International License (CC-BY-SA 4.0). 

See https://creativecommons.org/licenses/by-sa/4.0/ for details.
